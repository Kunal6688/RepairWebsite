import React from "react";

function CategoryBox(props) {
    return ( 
        <div className="flex flex-col mx-20 shadow-allShadow rounded-xl">
            <ul>
                <li className="stepsIcon flex mx-10 mt-10 "><img src={props.icon} alt="Step icon" /></li>
                <li className="stepsTitle mx-10 my-5 text-3xl font-bold text-gray-600">{props.title}</li>
                <li className="stepsContent text-gray-400 mx-10 mb-6 text-2xl">{props.content}</li>
            </ul>

        </div>
     );
}

export default CategoryBox;