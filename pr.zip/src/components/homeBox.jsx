import React from "react";
import StepsBox from "./homeStepsBox";
import Repair from "../assets/repair.png"

function HomeBox() {
    return ( 
    <div>
            <div className="grid grid-cols-1 md:grid-cols-2 place-items-center mx-72 mt-14  rounded-xl text-2xl bg-white shadow-allShadow">
              <div className="left p-4 w-full h-full flex flex-col justify-evenly items-center">
                <div className="upper mx-12 py-28">
                  <h1 className="text-gr text-6xl text-align font-semibold">Fast, affordable and    reliable       repairs</h1>
                  <p className="mt-2">for your mobile devices</p>
                </div>
                <div className="lower mt-4 py-14 ">
                  <button className="bg-button text-white py-4 px-14 rounded-lg">Book a Repair</    button>
                </div>
              </div>
              <div className="right  bg-orange-200 w-full h-full rounded-r-xl flex  items-center         justify-center">
                <img src={Repair} alt="Repair Image" className="w-full h-full rounded-r-xl" />
              </div>
            </div>
            
        </div>
     );
}

export default HomeBox;