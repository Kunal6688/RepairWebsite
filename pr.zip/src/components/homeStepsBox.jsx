import React from "react";

function StepsBox(props) {
    return ( 
        <div className="flex flex-col m-40 shadow-allShadow rounded-xl">
            <ul>
                <li className="stepsIcon flex items-center justify-center m-10 "><img src={props.icon} alt="Step icon" /></li>
                <li className="stepsTitle mx-20 my-10 text-3xl font-bold text-gray-600">{props.title}</li>
                <li className="stepsContent text-gray-400 mx-20 mb-14 text-2xl">{props.content}</li>
            </ul>
        </div>
     );
}

export default StepsBox;