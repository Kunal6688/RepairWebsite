import React from "react";
import logo from "../assets/logo_repair.png";

function Navbar() {
    return ( 
        <ul className="navItems bg-zinc-100 flex items-center justify-start px-7 py-4 text-2xl  flex-col text-nowrap sm:flex-row sm:justify-between">
            <li className="logo font-bold text-4xl">SS Repairs</li>
            <li className="navMenu">
                <ul className="flex gap-32">
                    <li className="hover:text-green-500"><a href="">Home</a></li>
                    <li className="hover:text-green-500"><a href="">About</a></li>
                    <li className="hover:text-green-500"><a href="">Contact</a></li>
                    <li className="hover:text-green-500"><a href="">FAQs</a></li>
                    
                </ul>
            </li>
            <li className="navButton">
                <button className="bg-button text-white p-3 rounded-lg">Book A Repair </button>
            </li>
        </ul>
       
     );
}

export default Navbar;